print("Python has 5 dataTypes: Number, String, List, Tuples, Dictionary")

print("\nString manipulation: ")

mystr = "Hungry kya?"

print(mystr)
print(mystr[0])
print(mystr[2:5])
print(mystr[2:])
print(mystr*2)
print(mystr+" Abhi Nahin")
print("String length: ", len(mystr))
print("Replacing: ", mystr.replace("kya", "?"))
print("Shifting: ", mystr.split(" "))

print("\nPython can handle integers, float and complex numbers ")

x = 33
y1 = 9.82
y2 = -54.3e100
z = 4j

print(type(x))
print(type(y1))
print(type(y2))
print(type(z))
