from AssignmentAt import AtomicDictionary

AtomicDictionary()
