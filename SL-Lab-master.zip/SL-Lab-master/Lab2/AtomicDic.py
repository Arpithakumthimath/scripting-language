list1 = ['H', 'Li', 'Li','He', 'H', 'Be','B', 'C', 'Li', 'N', 'N']
# List
print("\n list is")
# Printing List
print(list1)
# Occurence
Occurance1 = list1.count("N")
Occurance2 = list1.count("He")
Occurance3 = list1.count("Li")
# Occurence print
print("Number of occurance of N is",Occurance1)
print("Number of occurance of He is",Occurance2)
print("Number of occurance of Li is",Occurance3)
# Occurance List
print("List of Occurances\n")
Occur=["N", Occurance1],[ 'He', Occurance2],[ 'Li', Occurance3]
print(Occur)
