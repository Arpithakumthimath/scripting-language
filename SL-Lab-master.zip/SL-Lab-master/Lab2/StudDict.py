mydictionary1 = {
    "name": "Archie",
    "identity": "Student",
    "age": 17,
}
mydictionary2 = {
    "name": "Weatherbee",
    "identity": "Principal",
    "age": 52,
}

mydictionary3 = {
    "name": "MGrundy",
    "identity": "Teacher",
    "age": 51
}
print('\n dictionaries')
print(mydictionary1)
print(mydictionary2)
print(mydictionary3)
