# Scripting Language Lab Programs

## List of programs 

1. Introduction to Basic Python: 
    1. Python Basics - Datatypes,Lists
    2. Student Dictionary
    3. Atomic Dictionary
2. Extras on Python and JavaScript : Functions, Classes:
    1. Frequency of words in text file using python
    2. Temperature Convertion Function 
3. JavaScript and JSON programs:
    1. Display Book name and Authors
    2. Different datatypes in JSON
    3. Array Looping and accessing JSON
    4. Color Change using JSON
4. Programs using both JavaScript and Python:
    1. AgeCalculator
    2. Converting Min to H:M
    3. LetterSurround 
    4. odd numbers b/w range 
5. DataScience using python:
    1. BlackFriday Dataset
    2. Titanic Dataset
    3. StudentPreformance Dataset
    4. Iris Dataset
6. Flask:
    1. ATM program
    2. Shopping Cart program

