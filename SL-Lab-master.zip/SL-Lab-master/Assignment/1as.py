list = [1,'2',"three"]
print(len(list))
list.append([4,'5',"six"])
print(list)
print(list[1:2])
list[1]="apple"
print(list)
list2 = [7,"8","nine"]
print(list+list2)
