name=['ak','pl','lo']
print(name)
print("Lenght is:",len(name))
name=['sd','we','qw']
print("Lenght is:",len(name2))
name3=name1+name2
print(name3)
name[1]="mango"
print(name)
name4=[name]
print(name4)
tuple=(1,2,3)
print(tuple)
print(tuple[1])
print(tuple[1:2])
print(tuple[:2])
print("Length is:",len(tuple))
# Converting
ls = []
for i in tuple:
    ls.append(i)
print(ls)
