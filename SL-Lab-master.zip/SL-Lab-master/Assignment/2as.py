def HourMin(a):
        print(int(a/60), ":", (a%60))
print('Enter the parameter')
a=int(input())        
HourMin(a)

