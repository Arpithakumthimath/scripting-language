students={'1MS16IS001':'Asas','1MS16IS002':'raj','1MS16IS003':'pol'}
list={'value1','value2','value3'}
list2={}
j=0

for i in students
  print("key is",i,"value is",students[1])
    list[j]=students[i]
     #list2[j]=1 
      j=j+1
      
      print(list)
       print(students.keys()) 
       print(students.values()) 
       print(students.items()) 
       
